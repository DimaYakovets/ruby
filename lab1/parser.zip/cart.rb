class Cart 
  def initialize
    @items = []
  end

  def save_to_file()

  end

  def save_to_json()
    
  end

  def save_to_csv()

  end
end
