require_relative 'main_application'

app = MainApplication.new
app.info()
