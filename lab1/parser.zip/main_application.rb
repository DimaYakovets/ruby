require_relative 'init'

class MainApplication
  def start

  end
end
